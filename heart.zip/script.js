const ecgLine = document.querySelector('.ecg-line');

let isAnimating = false; // 标记是否正在动画

const path=[];
length = 150;
for (let i = 0; i < length; i++) {
    path.push(Math.random()*15); // 所有点为 0
}


// // 创建静止的心电图路径
const createFlatPath = () => {
    for (let i=0;i<length-1;i++){
        path[i]=path[i+1];
      }
        path[length-1]=(Math.random()*15); 
  return path;
};

// 创建波动的心电图路径（两个波峰）
const createWavePath = () => {
  for (let i=0;i<length-1;i++){
    path[i]=path[i+1];
  }
    
//   const path = [];
//   for (let i = 0; i < 20; i++) {
//     path.push(0); // 初始平稳段
//   }
//   path.push(50); // 第一个波峰

    path[length-6] = 76+Math.random()*15;
    path[length-5] = -100+Math.random()*15;
    path[length-4] = -25+Math.random()*15;
    path[length-3] = 0+Math.random()*15-7;
    path[length-2] = 100+Math.random()*15;
    path[length-1] = 25+Math.random()*15;

//   path.push(-50); // 第一个波峰
//   path.push(-25);
//   path.push(0);
//   path.push(-50); // 第二个波峰
//   path.push(-25);
// //   for (let i = 0; i < 20; i++) {
// //     path.push(0); // 结束平稳段
// //   }
//   length=length+5;
  return path;
};

// 生成SVG路径
const generateECG = (path) => {
  let d = '';
  path.forEach((point, index) => {
    const x = index * 10;
    const y = 100 + point;
    d += `${index === 0 ? 'M' : 'L'}${x},${y} `;
  });
  return d;
};

// 更新心电图路径
const updateECG = (isWave) => {
  const pathData = isWave ? createWavePath() : createFlatPath();
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  const path = document.createElementNS(svgNS, 'path');

  svg.setAttribute('width', '200%');
  svg.setAttribute('height', '200px');
  path.setAttribute('d', generateECG(pathData));
  path.setAttribute('fill', 'none');
  path.setAttribute('stroke', '#0f0');
  path.setAttribute('stroke-width', '2');

  svg.appendChild(path);
  ecgLine.innerHTML = ''; // 清空当前动画
  ecgLine.appendChild(svg);

  if (isWave) {
    ecgLine.style.animation = 'move-line 4s linear forwards'; // 设置动画
    isAnimating = true;
    setTimeout(() => {
      ecgLine.style.animation = 'none'; // 停止动画
      updateECG(false); // 恢复静止状态
      isAnimating = false;
    }, 50); // 动画结束后恢复静止状态
  }
};

// 初始化心电图为静止
updateECG(false);

// 监听按键事件
document.addEventListener('keydown', (e) => {
  if (e.key.toLowerCase() === 'b' && !isAnimating) {
    updateECG(true); // 触发波动
  }
});

setInterval(updateECG, 30,false);